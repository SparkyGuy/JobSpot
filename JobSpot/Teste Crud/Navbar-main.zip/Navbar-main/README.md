# Navbar
Uma simples e minimalista navbar, projeto feito no meu canal! Veja como eu fiz: https://www.youtube.com/c/GabiCode
